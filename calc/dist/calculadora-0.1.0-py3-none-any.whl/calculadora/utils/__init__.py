from calculadora.utils.fraccion import obtener_fracciones

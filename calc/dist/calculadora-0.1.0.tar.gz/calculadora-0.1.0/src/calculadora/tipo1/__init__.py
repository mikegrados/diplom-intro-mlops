from calculadora.tipo1.suma import suma
from calculadora.tipo1.resta import resta

from calculadora.tipo1 import suma, resta
from calculadora.tipo2 import multiplica

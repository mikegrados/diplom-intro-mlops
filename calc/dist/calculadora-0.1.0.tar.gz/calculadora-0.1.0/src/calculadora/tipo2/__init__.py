from calculadora.tipo2.division import division
from calculadora.tipo2.multiplica import multiplica
